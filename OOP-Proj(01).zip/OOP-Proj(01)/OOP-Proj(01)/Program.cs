﻿using System;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Book book1 = new Book(1,"book-1","author-1");
            //Book book2 = new Book(2, "book-2", "author-2");
            //Book book3 = new Book(3, "book-3", "author-3");
            Library library = new Library("CureMD-Library",1);
            int exit = 0;
            while (exit == 0)
            {
                Console.WriteLine("*** CureMD LIBRARY ***");
                Console.WriteLine("Choose an option (Write option number only): ");
                Console.WriteLine("1. Add a book");
                Console.WriteLine("2. Remove a book");
                Console.WriteLine("3. View all books");
                Console.WriteLine("4. Exit");
                int option = int.Parse(Console.ReadLine());

                switch(option){
                    case 1:
                        Console.Write("Enter book title: ");
                        string title = Console.ReadLine();
                        Console.Write("Enter book author: ");
                        string author = Console.ReadLine();
                        Console.Write("Enter book ID: ");
                        int bookID = int.Parse(Console.ReadLine());
                        Book book = new Book(bookID,title, author);
                        library.add_book(book);
                        break;
                    case 2:
                        Console.WriteLine("Enter book id you want to remove");
                        int bookid = int.Parse(Console.ReadLine());
                        Book remove_book = library.Books.Find(b => b.BookID == bookid);
                        library.remove_book(remove_book);
                        break;
                    case 3:
                        library.view_books();
                        break;

                    case 4:
                        exit = 1;
                        break;

                    default:
                        Console.WriteLine("Invalid choice");
                        break;
                }
            }
        }
    }
}
class Book {
    public string Title;
    public string Author;
    public int BookID;

    public Book(int bookid, string title, string author)
    {
        Title = title;
        Author = author;
        BookID = bookid;
    }
    public void display_info()
    {
        Console.WriteLine($"Title: {Title} Author: {Author} BookID: {BookID}");
    }
}
class Person {
    public string Name;
    public int Age;
    public int PersonID;
}

class Library {
    public string Library_Name;
    public int Library_ID;
    public List<Book> Books;

    public Library(string name,int id)
    {
        Library_Name = name;
        Library_ID = id;
        Books = new List<Book>();
    }
    public void add_book(Book book)
    {
        Books.Add(book);

    }
    public void remove_book(Book book)
    {
        Books.Remove(book);
    }
    public void view_books()
    {
        foreach (Book book in Books)
        {
            book.display_info();
        }
    }
}

