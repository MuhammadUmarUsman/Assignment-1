﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Data;
using System.Security.Cryptography;
using System.Xml.Linq;
using System.Xml.Serialization;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //int[] arr = { 1, 2, 3, 3, 3, 3, 4, 4, 5, 5, 6 };

            //int[] result = deleteDuplicates(arr);
            //foreach (int i in result)
            //{
            //    Console.Write(i);
            //}

            //FindLargest(arr);

            //int[] arr2 = { 1, 2, 0, 0, 4, 0, 3, 0, 1, 2 };

            //int[] results = MoveZeros(arr2);
            //foreach (int i in results)
            //{
            //    Console.Write(i);
            //}

            //Console.WriteLine(FindNonRepeating("hello"));

            //int[] arr_1 = { 2, 3, 4, 5 };
            //int[] arr_2 = { 5, 6, 7, 8 };

            //int[] result_array = MergeArrays(arr_1, arr_2);
            //foreach (int i in result_array)
            //{
            //    Console.Write(i);
            //}
            //Console.WriteLine("Enter a number n: ");
            //int n = int.Parse(Console.ReadLine()); 
            //Fibonacci(n);
            //Statistics();

            //missingNumbers(arr_1);
            //Console.WriteLine(Armstrong(153));
            //string[] strings = { "hellooooo", "helloooo", "hell", "hello" };
            //Console.WriteLine(LongestCommonPrefix(strings));
        }

        //Question#1
        //method-1
        static int[] deleteDuplicates(int[] arr)
        {
            HashSet<int> set = new HashSet<int>(arr); // Initialize a hash set with values of given array  // 'set' do not repeat values so it will automatically delete duplicates.
            return set.ToArray();  // Convert the set to array and return.  
        }
        //method-2
        static int[] deleteDuplicates2(int[] arr)
        {
            List<int> list = arr.ToList(); // convert the array to list and save in a list 'list'
            for (int i = 0; i < list.Count; i++) // start an outer for loop from zero to length of the list
            {
                for (int j = i + 1; j < list.Count; j++) // start an inner for loop from i+1 to length of the list
                {
                    if (list[i] == list[j]) // check if number at index i in the list is equal to number at index j
                    {
                        list.RemoveAt(j); // remove the duplicate from list at position j (if num at i matches num at j it will remove the second number)
                        j--; // decrement j by 1 as removing one number decreases array size and index position of numbers change
                    }
                }
            }
            return list.ToArray(); //Convert the list to array and return.
        }

        //Question#2
        static void FindLargest(int[] arr)
        {
            int largest = int.MinValue; // declare an integer 'largest' and initialize it with smallest value of int
            int secondLargest = int.MinValue; // declare a second integer 'secondLargest' and initialize it with smallest value of int
            foreach (int i in arr) // a loop iterating through all the values in array
            {
                if (i > largest) // check if a num is greater than the number stored in largest
                {
                    secondLargest = largest; // assign value of largest to secondlargest
                    largest = i; // assign value of current num in the loop to largest
                }
                if (i > secondLargest && i != largest) // check if current number at i is greater than num stored in secondLargest
                {
                    secondLargest = i; //assign value of current num in the loop to secondlargest
                }
            }
            Console.WriteLine("Largest: " + largest); // print largest and second largest values
            Console.WriteLine("Second Largest: " + secondLargest);
        }

        //Question#3
        static int[] MoveZeros(int[] arr)
        {
            List<int> list = new List<int>(arr); //declare a list and initialize it with the values of array
            foreach (int num in arr) //iterate through each num in list
            {
                if (num == 0) //check if num == 0
                {
                    list.Remove(num); //remove the zero from list
                    list.Add(num); // add the zeroes back as .Add funcion adds the number in the end
                }
            }
            return list.ToArray(); //Convert the list to array and return. 
        }

        //Question#4
        static string FindNonRepeating(string str)
        {
            Dictionary<char, int> dictCharCount = new Dictionary<char, int>(); // create a dictionary to save characters with their repitition number
            foreach (char c in str) // iterate through each character in the string
            {
                if (dictCharCount.ContainsKey(c)) // check if the current character in loop is already present in the dictionary
                {
                    dictCharCount[c] += 1; // increment the count value of character by 1 if it is already present
                }
                else
                {
                    dictCharCount[c] = 1; // save current character in loop as key and its value as 1 if its not already present
                }
            }
            foreach (char c in str) //loop through the string
                if (dictCharCount[c] == 1) // check which character has a value of 1 in dict
                {
                    return c.ToString(); // return first non-repeating character
                }
            return "no non repeating char"; // return if no non repeating found
        }
           

    //Question#5
    static int[] MergeArrays(int[] arr1, int[] arr2)
    {
        List<int> newList = new List<int>(); //declare a list
        foreach (int val in arr1) // loop through each item in the array 1
        {
            newList.Add(val); //save all the values of first array in list
        }

        foreach (int val in arr2) // loop through each item in the array 1 
            {
            newList.Add(val); //save all the values of second array in list
        }
        for (int i = 0; i < newList.Count - 1; i++) // now to sort the list use nested loops 
        {
            for (int j = 0; j < newList.Count - i - 1; j++) // loop from 0 to Count-i-1 bec after each iteration the largest number will go to end so we dont need to go till last number so we keep decreasing
            {
                if (newList[j] > newList[j + 1]) // swap where current number is greater then next number (j > j+1 condition to check)
                {
                    int temp = newList[j]; // save j in temp
                    newList[j] = newList[j + 1]; // assign value in j+1 to j
                    newList[j + 1] = temp; // assign value in temp to j+1
                }
            }
        }
        HashSet<int> MergedArray = new HashSet<int>(newList);//convert list to hashset to delete duplicates
        return MergedArray.ToArray(); //return the sorted merged array
    }

    //Question#6
    static void missingNumbers(int[] arr)
    {

        HashSet<int> newSet = new HashSet<int>(); // declare a hashset
        List<int> missing = new List<int>(); // declare a new list
        for (int i = 0; i < arr.Length; i++) //a loop from 0 till array length
        {
            newSet.Add(i); //add all numbers from 0 to length of array in the set
        }
        foreach (int val in arr) // loop through each value in array
        {
            if (!newSet.Contains(val)) // check if the set contains that value
            {
                missing.Add(val); // save the missing value in missing list
            }
        }
        if (missing.Count != 0) // check if missing list is empty or not
        {
            Console.Write("Missing Numbers: ");
            foreach (int i in missing) // print all the numbers in missing list
            {
                Console.Write(i + " ");
            }
        }
        else
        {
            Console.WriteLine("no missing numbers"); // if list is empty print no missing num
        }

    }
    //Question#7
    static bool Armstrong(int num)
    {
        int number = num; // save given number in an integer number
        int total_digits = num.ToString().Length; //to calculate length convert to string and use .Length.
        int totalSum = 0; //initialize total sum = 0;
        while (num > 0) // check if number is greater then zero go inside loop body
        {
            int digit = num % 10; // take mod with 10 to save last digit of num in 'digit'
            totalSum += (int)Math.Pow(digit, 3); //add cube of digit to totalSum.
            num = num / 10; //divide the number by 10 so next time mod by 10 gives us the other digit // repeat untill all digits cubed and added
        }
        return number == totalSum; //return true if sum of all digits equal totalSum(sum of cubes of digits).
    }

    //Question#8
    static string LongestCommonPrefix(string[] str)
    {
        if (str == null || str.Length == 0) // if string is null or empty return "empty array"
            return "Empty Array";
        string prefix = str[0]; // save the first string in arr in prefix

        for (int i = 1; i < str.Length; i++) // loop from 1 to string length (start from second element bec we have already saved first string in prefix to compare)
        {
            while (str[i].IndexOf(prefix) != 0) //check if ith string in array contains the prefix
            {
                prefix = prefix.Substring(0, prefix.Length - 1); //if yes then decrease the prefix string by one 
                if (prefix.Length == 0) // if the string gets empty it means their is no common prefix
                    return "no common prefix";
            }
        }

        return prefix; //return the prefix
    }
    //Question#9
    static void Fibonacci(int n)
    {
        int num1 = 0; //declare and initializd num 1 by 0;
        int num2 = 1; //declare and initializd num 2 by 1;
        int count = 0; //declare and initializd count by 0
        Console.Write(num1 + " " + num2 + " "); // print first 2 numbers of fibonacci series (num1 and num2)
        int num3 = num1 + num2; // initialize num3 with sum of num1 and num2
        while (count < n) // if count is less than the number n go inside the loop
        {
            Console.Write(num3 + " "); // print num3
            num1 = num2; // assign value of num2 to num1
            num2 = num3; // assign value of num3 to num2
            num3 = num1 + num2; //assign the sum of num1 and num2 to num3 
            count++; //increment the count by 1
        }

    }
    //Question#10:
    static void Statistics()
    {
        Console.Write("Enter N: "); //prompt user to enter a number 
        int N = int.Parse(Console.ReadLine()); // read that number and save in variable N

        Console.Write($"Enter {N} integers with space between: "); //ask user to write N integers with space between
        string nums = Console.ReadLine(); //read the user input and save in string variable nums
        string[] numArr = nums.Split(' '); //split the nums string into a num array

        int[] numbers = new int[N]; //declare a number array with size equal to number of integers entered.

        for (int i = 0; i < numArr.Length; i++) //loop from 0 to length of array
        {
            numbers[i] = int.Parse(numArr[i]); // covert each string of number in string array to integer and save in ith position in numbers array
        }
        int positive = 0; //initialize positive, negative,sum,and avg to 0;
        int negative = 0;
        int sum = 0;
        double avg = 0;

        foreach (int num in numbers) //loop through each num in number array
        {
            if (num > 0) //check if num is positive
                positive++; //increment positive by one
            else if (num < 0) //check if num is negative
                    negative++; //increment negative by one

                sum += num; // keep adding all the numbers to sum variable
        }
        avg = (double)sum / numbers.Length; //calculate average by dividing sum by total numbers

        Console.WriteLine($"Number of positive integers: {positive}"); //print positive, negative,sum and average
        Console.WriteLine($"Number of negative integers: {negative}");
        Console.WriteLine($"Total sum of integers: {sum}");
        Console.WriteLine($"Average: {avg}");
      }
     }
    }
    
