using Microsoft.AspNetCore.Mvc;
using BookStoreApi.BusinessLayer;
using BookStoreApi.Models;
using BookStoreApi.DataAccessLayer;

namespace BookStoreApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class BooksController : ControllerBase
    {
        private readonly BookBusinessLayer bookBL = new BookBusinessLayer();

        [HttpGet]
        public ActionResult<IEnumerable<Book>> GetBooks()
        {
            return Ok(bookBL.GetBooks());
        }

        [HttpGet("{id}")]
        public ActionResult<Book> GetBook(int id)
        {
            var book = bookBL.GetBook(id);
            if (book == null)
            {
                return NotFound(new { Message = "Book not found" });
            }
            return Ok(book);
        }

        [HttpPost]
        public ActionResult<Book> AddBook(Book book) {
            if (book == null)
            {
                return BadRequest(new { Message = "Invalid book data" });
            }
            bookBL.AddBook(book);
            return CreatedAtAction(nameof(GetBook), new { id = book.Id }, book);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateBook(int id,Book book)
        {
            var existingBook = bookBL.GetBook(id);
            if(existingBook == null){
                return NotFound(new { Message = "Book not found" });
            }
            bookBL.UpdateBook(id,book);
            return Ok(new {Message = "Suceesfully updated the book" });
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteBook(int id)
        {
            var existingBook = bookBL.GetBook(id);
            if (existingBook == null)
            {
                return NotFound(new { Message = "Book not found" });
            }

            bookBL.DeleteBook(id);
            return Ok(new { Message = "Book deleted successfully" });
        }
        [HttpGet("author/{author}")]
        public ActionResult<IEnumerable<Book>> GetBookByAuthor(string author)
        {
            var booksByAuthor = bookBL.GetBookByAuthor(author);
            if (booksByAuthor == null)
            {
                return NotFound(new { Message = "No books found for the specified author" });
            }
            return Ok(booksByAuthor);
        }
    }
}
