﻿using BookStoreApi.Models;
namespace BookStoreApi.DataAccessLayer
{
    public class BookDAL
    {
        List<Book> books = new List<Book>
        {
            new Book { Id = 1, Title = "The Great Gatsby", Author = "F. Scott Fitzgerald", Price = "$10.99", ImageUrl = "Images/book-1.jpg", Description = "A novel set in the Jazz Age that examines the American dream." },
            new Book { Id = 2, Title = "To Kill a Mockingbird", Author = "Harper Lee", Price = "$8.99", ImageUrl = "Images/book-1.jpg", Description = "A classic novel about racial injustice in the Deep South." },
            new Book { Id = 3, Title = "1984", Author = "George Orwell", Price = "$9.99", ImageUrl = "Images/book-1.jpg", Description = "A dystopian novel exploring totalitarianism and surveillance." },
            new Book { Id = 4, Title = "Pride and Prejudice", Author = "Jane Austen", Price = "$7.99", ImageUrl = "Images/book-1.jpg", Description = "A romantic novel about manners and marriage in early 19th century England." },
            new Book { Id = 5, Title = "The Catcher in the Rye", Author = "J.D. Salinger", Price = "$6.99", ImageUrl = "Images/book-1.jpg", Description = "A story about teenage rebellion and alienation." },
            new Book { Id = 6, Title = "The Hobbit", Author = "J.R.R. Tolkien", Price = "$8.49", ImageUrl = "Images/book-1.jpg", Description = "A fantasy novel about the adventure of Bilbo Baggins." },
            new Book { Id = 7, Title = "Moby Dick", Author = "Herman Melville", Price = "$11.99", ImageUrl = "Images/book-1.jpg", Description = "A novel about the obsessive quest of Captain Ahab for revenge on Moby Dick." },
            new Book { Id = 8, Title = "War and Peace", Author = "Leo Tolstoy", Price = "$12.99", ImageUrl = "Images/book-1.jpg", Description = "An epic novel about Russian society during the Napoleonic era." },
            new Book { Id = 9, Title = "The Alchemist", Author = "Paulo Coelho", Price = "$9.49", ImageUrl = "Images/book-1.jpg", Description = "A philosophical novel about a shepherd's journey to find treasure." },
            new Book { Id = 10, Title = "Jane Eyre", Author = "Charlotte Brontë", Price = "$7.49", ImageUrl = "Images/book-1.jpg", Description = "A novel about the experiences of an orphaned girl in 19th century England." },
            new Book { Id = 11, Title = "The Book Thief", Author = "Markus Zusak", Price = "$8.99", ImageUrl = "Images/book-1.jpg", Description = "A novel narrated by Death about a young girl in Nazi Germany." },
            new Book { Id = 12, Title = "Crime and Punishment", Author = "Fyodor Dostoevsky", Price = "$10.49", ImageUrl = "Images/book-1.jpg", Description = "A novel exploring the moral dilemmas faced by a young Russian student." },
            new Book { Id = 13, Title = "Brave New World", Author = "Aldous Huxley", Price = "$9.99", ImageUrl = "Images/book-1.jpg", Description = "A dystopian novel set in a technologically advanced future." },
            new Book { Id = 14, Title = "The Adventures of Huckleberry Finn", Author = "Mark Twain", Price = "$7.99", ImageUrl = "Images/book-1.jpg", Description = "A novel about the adventures of a young boy on the Mississippi River." },
            new Book { Id = 15, Title = "Anna Karenina", Author = "Leo Tolstoy", Price = "$11.49", ImageUrl = "Images/book-1.jpg", Description = "A novel about the tragic love affair between Anna Karenina and Count Vronsky." },
            new Book { Id = 16, Title = "The Grapes of Wrath", Author = "John Steinbeck", Price = "$8.49", ImageUrl = "Images/book-1.jpg", Description = "A novel about the struggles of a poor family during the Great Depression." },
            new Book { Id = 17, Title = "Frankenstein", Author = "Mary Shelley", Price = "$6.99", ImageUrl = "Images/book-1.jpg", Description = "A novel about a scientist who creates a sentient creature." },
            new Book { Id = 18, Title = "Wuthering Heights", Author = "Emily Brontë", Price = "$7.49", ImageUrl = "Images/book-1.jpg", Description = "A novel about the passionate and destructive love between Catherine and Heathcliff." }
        };
        public List<Book> GetBook()
        {
            return books;
        }
        public Book? GetBook(int id)
        {
            return books.FirstOrDefault(book => book.Id == id);
        }
        public void AddBook(Book book)
        {
            book.Id = books.Max(b => b.Id) + 1;
            books.Add(book);
        }
        public void UpdateBook(Book book)
        {
            var existingBook = books.FirstOrDefault(b => b.Id == book.Id);
            if (existingBook != null)
            {
                existingBook.Title = book.Title;
                existingBook.Author = book.Author;
                existingBook.Description = book.Description;
                existingBook.ImageUrl = book.ImageUrl;
        }
    }
        public void DeleteBook(int id)
        {
            var book = books.FirstOrDefault(b => b.Id == id);
            if (book != null)
            {
                books.Remove(book);
            }
        }
        public List<Book> GetBooksByAuthor(string author)
        {
            List<Book> result = new List<Book>();
            foreach (Book book in books)
            {
                if (book.Author.ToLower() == author.ToLower())
                {
                    result.Add(book);
                }
            }
            return result;
        }
    }
}
