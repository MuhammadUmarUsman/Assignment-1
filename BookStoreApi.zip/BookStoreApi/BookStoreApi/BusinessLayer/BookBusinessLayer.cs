﻿using BookStoreApi.DataAccessLayer;
using BookStoreApi.Models;

namespace BookStoreApi.BusinessLayer
{
    public class BookBusinessLayer
    {
        private readonly BookDAL bookDAL = new BookDAL();

        public List<Book> GetBooks() {
            return bookDAL.GetBook();
        }

        public Book? GetBook(int id) {
            return bookDAL.GetBook(id);
        }

        public void AddBook(Book book)
        {
            bookDAL.AddBook(book);
        }

        public void UpdateBook(int id, Book book) {
            Book existingBook = GetBook(id);
            if (existingBook != null)
            {
                book.Id = id;
                bookDAL.UpdateBook(existingBook);
            }
        }
        public void DeleteBook(int id)
        {
            bookDAL.DeleteBook(id);
        }

        public List<Book> GetBookByAuthor(string author) {
            return bookDAL.GetBooksByAuthor(author);
        }
    }
}
