﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management_System
{
    internal class Person
    {
        //public Person(string name, int age, int id)
        //{
        //    person_name = name;
        //    person_age = age;
        //    person_id = id;
        //}
        public string person_name;
        public int person_age;
        public int person_id;
    }
}
