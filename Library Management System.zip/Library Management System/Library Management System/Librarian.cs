﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management_System
{
    internal class Librarian : Person
    {
        public int Employee_ID;
        public Librarian(int Emp_id) {
            Employee_ID = Emp_id;
        }

        public void issue_book(Book book,Person user)
        {
            if (book.isIssued)
            {
                Console.WriteLine("The book is already issued");
            }
            else
            {
                book.isIssued = true;
                book.issued_name = user.person_name;
                Console.WriteLine($"*****{book.Title} is issued to {user.person_name}*****");
            }  
        }
        public void return_book(Book book, Person user)
        {
            if (!book.isIssued)
            {
                Console.WriteLine("This book was not issued");
            }
            else
            {
                book.issued_name = "";
                book.isIssued = false;
                Console.WriteLine($"*****{user.person_name} returned {book.Title}*****");
            }
        }

    }
}
