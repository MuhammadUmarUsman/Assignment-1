﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management_System
{
    internal class Library
    {
        public string lib_name;
        public int lib_id;
        public List<Book> books;
        public Librarian librarian;

        public Library() { }
        public Library(string lib_name,int lib_id, int emp_id) {
            lib_name = lib_name; 
            lib_id = lib_id;
            books = new List<Book>();
            librarian = new Librarian(emp_id);
        }

        public void add_book(Book book) { 
            books.Add(book);
            Console.WriteLine($"*****{book.Title} added to the library*****");
        }
        public void remove_book(int book_id) {
            bool found = false;
            if(books.Count == 0) {
                Console.WriteLine("Library has no books");
            }
            else
            {
                foreach (Book book in books)
                {
                    if (book.Book_id == book_id)
                    {
                        books.Remove(book);
                        found = true;
                        Console.WriteLine($"*****{book.Title} removed from the library*****");
                        break;
                    }
                }
                if (!found)
                {
                    Console.WriteLine($"No book with id: {book_id}");
                }
            }

        }
        public void view_books() {
            if (books.Count != 0) {
                Console.WriteLine("Books in the library: ");
                Console.WriteLine("-----------------------------");
                foreach (Book book in books)
                {
                    book.display_info();
                    Console.WriteLine("-----------------------------");
                }
            }
            else
            {
                Console.WriteLine("Library has no books");
            }
        }
        public void search_book(string title)
        {
            foreach (Book book in books) { 
                if(book.Title.ToLower() == title.ToLower())
                {
                    book.display_info();
                }
            }
        }

        public void list_issued_books()
        {
            bool flag = false;
            foreach (Book book in books) {
                if (book.isIssued)
                {
                    book.display_info();
                    Console.WriteLine("-----------------------------");
                    flag = true;
                }
            }
            if (!flag) {
                Console.WriteLine("No Books are issued");
            }
        }
    }
}
