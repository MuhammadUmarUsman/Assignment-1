﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management_System
{
    abstract class Book
    {
        public string Title;
        public string Author;
        public int Book_id;
        public bool isIssued;
        public string issued_name;
        public Book() { }
        
        public Book(int book_id, string title, string author) {
            Title = title;
            Author = author;
            Book_id = book_id;
            isIssued = false;
            issued_name = "";        }

        public abstract void display_info();
    }
}
