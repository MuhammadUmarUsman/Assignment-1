﻿using System;

namespace Library_Management_System
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
