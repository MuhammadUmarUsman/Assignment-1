﻿using System;

namespace Library_Management_System
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Library lib = new Library("CureMD Library",609,101);
            bool Exit = false;
            while (!Exit)
            {
                Console.Clear();
                bool exit = false;
                Console.WriteLine("******Welcome to our Library Management System*****");
                Console.WriteLine("Enter 1 to login as Admin");
                Console.WriteLine("Enter 2 to login as a user");
                Console.WriteLine("Enter 3 to exit");

                int login_type = int.Parse(Console.ReadLine());
                Console.Clear();
                if (login_type == 1)
                {
                    while (!exit)
                    {
                        Console.WriteLine("Select any option: ");
                        Console.WriteLine("1. Add a book to the Library");
                        Console.WriteLine("2. Remove a book from Library");
                        Console.WriteLine("3. View all the books");
                        Console.WriteLine("4. Exit Admin Panel");
                        int option = int.Parse(Console.ReadLine());
                        switch (option)
                        {
                            case 1:
                                Console.Clear();
                                Console.WriteLine("Book type:");
                                Console.WriteLine("1.Fiction");
                                Console.WriteLine("2.NonFiction");
                                int type = int.Parse(Console.ReadLine());
                                if (type == 1)
                                {
                                    Console.WriteLine("Provide the following information: ");
                                    Console.Write("Book Id: ");
                                    int book_id = int.Parse(Console.ReadLine());
                                    Console.Write("Book Title: ");
                                    string book_name = Console.ReadLine();
                                    Console.Write("Book Author: ");
                                    string author = Console.ReadLine();
                                    Console.Write("Genre: ");
                                    string genre = Console.ReadLine();


                                    Book book = new FictionBook(book_id, book_name, author, genre);
                                    lib.add_book(book);
                                }
                                else
                                {
                                    Console.WriteLine("Provide the following information: ");
                                    Console.Write("Book Id: ");
                                    int book_id = int.Parse(Console.ReadLine());
                                    Console.Write("Book Title: ");
                                    string book_name = Console.ReadLine();
                                    Console.Write("Book Author: ");
                                    string author = Console.ReadLine();
                                    Console.Write("Subject: ");
                                    string subject = Console.ReadLine();


                                    Book book = new NonFictionBook(book_id, book_name, author, subject);
                                    lib.add_book(book);
                                }
                                break;
                            case 2:
                                Console.Clear();
                                Console.Write("Tell the id of book you want to remove: ");
                                int remove_id = int.Parse(Console.ReadLine());
                                lib.remove_book(remove_id);
                                break;
                            case 3:
                                Console.Clear();
                                lib.view_books();
                                break;
                            case 4:
                                exit = true;
                                break;
                        }
                    }
                }
                else if (login_type == 2)
                {
                    Console.Clear();
                    Console.Write("username: ");
                    string username = Console.ReadLine();
                    Person user = new Person();
                    user.person_name = username;
                    Console.Clear();
                    while (!exit)
                    {
                        Console.WriteLine("Select any option: ");
                        Console.WriteLine("1. Search Books");
                        Console.WriteLine("2. Issue a book");
                        Console.WriteLine("3. Return a book");
                        Console.WriteLine("4. List issued books");
                        Console.WriteLine("5. Exit User Panel");

                        int option = int.Parse(Console.ReadLine());
                        switch (option)
                        {
                            case 1:
                                Console.Clear();
                                Console.Write("Search book (provide title): ");
                                string search_title = Console.ReadLine();
                                lib.search_book(search_title);
                                break;
                            case 2:
                                Console.Clear();
                                Console.Write("Which book do you want to issue: ");
                                string book_to_issue = Console.ReadLine();
                                Book issued = lib.search_book(book_to_issue);
                                lib.librarian.issue_book(issued,user);
                                break;
                            case 3:
                                Console.Clear();
                                Console.Write("Book to return: ");
                                string book_to_return = Console.ReadLine();
                                Book returned = lib.search_book(book_to_return);
                                lib.librarian.return_book(returned,user);
                                break;
                            case 4:
                                Console.Clear();
                                lib.list_issued_books();
                                break;
                            case 5:
                                exit = true;
                                break;
                        }
                    }
                }
                else
                {
                    Exit = true;
                }
            }
        }
    }
}
