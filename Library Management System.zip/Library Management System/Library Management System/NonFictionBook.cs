﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management_System
{
    internal class NonFictionBook : Book
    {
        public string Subject;
        public NonFictionBook(int book_id, string title, string author, string subject)
        {
            Title = title;
            Author = author;
            Book_id = book_id;
            Subject = subject;
            isIssued = false;
            issued_name = "";
        }
        public override void display_info()
        {
            Console.WriteLine($"Book id: {Book_id}");
            Console.WriteLine($"Title: {Title}");
            Console.WriteLine($"Author: {Author}");
            Console.WriteLine($"Subject: {Subject}");
        }
    }
}
