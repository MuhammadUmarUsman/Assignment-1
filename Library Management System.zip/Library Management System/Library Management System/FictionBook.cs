﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management_System
{
    internal class FictionBook : Book
    {
        public string Genre;
        public FictionBook(int book_id, string title, string author, string genre)
        {
            Title = title;
            Author = author;
            Book_id = book_id;
            Genre = genre;
            isIssued = false;
        }
        public override void display_info()
        {
            Console.WriteLine($"Book id: {Book_id}");
            Console.WriteLine($"Title: {Title}");
            Console.WriteLine($"Author: {Author}");
            Console.WriteLine($"Genre: {Genre}");
        }
    }
}
