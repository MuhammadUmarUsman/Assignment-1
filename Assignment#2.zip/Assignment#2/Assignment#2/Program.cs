﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Xml.Serialization;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //int[] arr = { 1, 2, 3, 3, 3, 3, 4, 4, 5, 5, 6 };

            //int[] result = deleteDuplicates(arr);
            //foreach (int i in result)
            //{
            //    Console.Write(i);
            //}

            // FindLargest(arr);

            //int[] arr = { 1, 2, 0, 0, 4, 0, 3, 0, 1, 2 };

            //int[] result = MoveZeros(arr);
            //foreach (int i in result)
            //{
            //    Console.Write(i);
            //}

            //Console.WriteLine(FindNonRepeating("hello"));

            //int[] arr1 = { 1, 2, 3,5};
            //int[] arr2 = { 5, 6, 7, 8 };

            //int[] result = MergeArrays(arr1,arr2);
            //foreach (int i in result)
            //{
            //    Console.Write(i);
            //}
            Fibonacci(10);
        }

        //Question#1
        //method-1
        static int[] deleteDuplicates(int[] arr)
        {
            HashSet<int> set = new HashSet<int>(arr);
            return set.ToArray();
        }
        //method-2
        //    static int[] deleteDuplicates(int[] arr)
        //    {
        //        List<int> list =  arr.ToList();
        //        for(int i = 0;i<list.Count;i++)
        //        {
        //            for (int j=i+1;j<list.Count; j++)
        //            {
        //                if(list[i] == list[j])
        //                {
        //                    list.RemoveAt(j);
        //                    j--;
        //                }
        //            }
        //        }
        //        return list.ToArray();
        //    }

        //Question#2
        static void FindLargest(int[] arr)
        {
            int largest = int.MinValue;
            int secondLargest = int.MinValue;
            foreach(int i in arr)
            {
                if ( i > largest)
                {
                    secondLargest = largest;
                    largest = i;
                }
                if (i > secondLargest && i != largest)
                {
                    secondLargest = i;
                }
            }
            Console.WriteLine("Largest: " + largest);
            Console.WriteLine("Second Largest: " + secondLargest);
        }

        //Question#3
        static int[] MoveZeros(int[] arr)
        {
            List<int> list = new List<int>(arr);
            foreach(int num in arr)
            {
                if(num == 0)
                {
                    list.Remove(num);
                    list.Add(num);
                }
            }
            return list.ToArray();
        }

        //Question#4
        static string FindNonRepeating(string str)
        {
            Dictionary<char,int> dictCharCount= new Dictionary<char,int>();
            foreach(char c in str)
            {
                if (dictCharCount.ContainsKey(c))
                {
                    dictCharCount[c] += 1;
                }
                else
                {
                    dictCharCount[c] = 1;
                }
            }
            foreach(char c in str)
            {
                if (dictCharCount[c]== 1)
                {
                    return c.ToString();
                }
            }
            return "no non repeating char";
        }

        //Question#5
        static int[] MergeArrays(int[] arr1, int[] arr2)
        {
            List<int> newList = new List<int>();
            foreach (int val in arr1)
            {
                newList.Add(val);
            }

            foreach (int val in arr2)
            {
                newList.Add(val);
            }
            for (int i = 0; i < newList.Count - 1; i++)
            {
                for (int j = 0; j < newList.Count - i - 1; j++)
                {
                    if (newList[j] > newList[j + 1])
                    {
                        int temp = newList[j];
                        newList[j] = newList[j + 1];
                        newList[j + 1] = temp;
                    }
                }
            }
            HashSet<int> MergedArray = new HashSet<int>(newList);
            return MergedArray.ToArray();
        }
        //Question#9
        static void Fibonacci(int n)
        {
            int num1 = 0;
            int num2 = 1;
            Console.Write(num1+" "+num2+" ");
            int num3 = num1 + num2;
            while (num3 < n)
            {
                Console.Write(num3 + " ");
                num1 = num2;
                num2 = num3;
                num3 = num1 + num2;
            }

        }
        //Question#10:
        static void Statistics()
        {
            Console.WriteLine("Enter N: ");
            int N = int.Parse(Console.ReadLine());

            Console.WriteLine($"Enter {N} integers");
            string nums = Console.ReadLine();
            string[] numArr = nums.Split(' ');

            int[] numbers = new int[N];

            for(int i=0;i<numArr.Length;i++)
            {
                numbers[i] = int.Parse(numArr[i]);
            }
            int positive = 0;
            int negative = 0;
            int sum = 0;
            double avg = 0;

            foreach (int num in numbers)
            {
                if (num > 0)
                    positive++;
                else if (num < 0)
                    negative++;

               sum += num;
            }
            avg = (double)sum / numbers.Length;

            Console.WriteLine($"Number of positive integers: {positive}");
            Console.WriteLine($"Number of negative integers: {negative}");
            Console.WriteLine($"Total sum of integers: {sum}");
            Console.WriteLine($"Average of integers: {avg}");
        } 

    }
    }

